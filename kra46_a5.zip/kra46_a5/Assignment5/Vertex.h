#ifndef VERTEX_H
#define VERTEX_H
#include "Angel.h"
typedef struct
{
    vec4 Position;
    vec4 Color;
    vec3 normal;
}Vertex3D;
#endif
